# Arduino Core for Fasal SAMD21E18 MCU

This repository containts the source code and configuration files of the Arduino Core
for STM's STM32F103CBxx (used on the Fasal Project-F4 Board).

<!-- ## Installation on Arduino IDE

This core is available as a package in the Arduino IDE cores manager.

## Support

This core is for internal use, and released to public as is.

-->

## Bugs or Issues

Email to connect@wolkus.com

## Note
Fasal is a brand name associated with Wolkus Technology Solutions Private Limited, Bangalore. More info at http://fasal.co

## License and credits

This core has been developed by Abhay Bharadwaj and has been forked from Roger Clark's STM32Duino code Release: 2019.11.26
```
  Copyright (c) 2015 Arduino LLC.  All right reserved.
  Copyright (c) 2021 Abhay.S.Bharadwaj.  All right reserved.
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
```
