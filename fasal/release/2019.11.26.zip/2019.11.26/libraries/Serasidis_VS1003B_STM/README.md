Description
---

That library is for VS1003B / VS10053B WAV/MP3/AAC audio decoder. 
The library has been ported to work with STM32 micro-controllers.

A short Youtube video demonstration of the library can be found [here][A].
In that video I used an **STM32F103C8T** development board and a **VS1053B** mp3 decoder module.

[A]:https://www.youtube.com/watch?v=oTPFkK0scAI
